import React from 'react';
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Pie, Bar, Line } from 'react-chartjs-2';

ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Dashboard = () => {
  // Pending Work Data
  const pendingWorkData = {
    labels: ['High', 'Medium', 'Low'],
    datasets: [{
      data: [12, 19, 8],
      backgroundColor: ['#EF4444', '#F59E0B', '#10B981'],
      borderWidth: 0,
    }]
  };

  // Performance Data
  const performanceData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [{
      label: 'Performance Score',
      data: [65, 72, 68, 75, 82, 85],
      borderColor: '#6366F1',
      backgroundColor: 'rgba(99, 102, 241, 0.1)',
      tension: 0.4,
      fill: true,
    }]
  };

  // Completed Work Data
  const completedWorkData = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    datasets: [
      {
        label: 'Bugs Fixed',
        data: [20, 15, 25, 18],
        backgroundColor: 'rgba(245, 158, 11, 0.9)',
      },
      {
        label: 'Features Developed',
        data: [15, 20, 15, 22],
        backgroundColor: 'rgba(16, 185, 129, 0.9)',
      },
      {
        label: 'Documents Completed',
        data: [10, 12, 8, 15],
        backgroundColor: 'rgba(99, 102, 241, 0.9)',
      },
    ]
  };

  // Notifications Data
  const notificationsData = {
    labels: ['Mentions', 'Meetings', 'Deadlines', 'Updates'],
    datasets: [{
      data: [8, 12, 6, 15],
      backgroundColor: ['#6366F1', '#F59E0B', '#EF4444', '#10B981'],
      borderWidth: 0,
    }]
  };

  return (
    <div className="grid grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-semibold mb-4 text-slate-800">Pending Work by Priority</h3>
        <Pie data={pendingWorkData} options={{
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                usePointStyle: true,
                padding: 20,
              }
            }
          }
        }} />
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-semibold mb-4 text-slate-800">Performance Trend</h3>
        <Line data={performanceData} options={{
          scales: {
            y: {
              beginAtZero: true,
              max: 100,
              grid: {
                color: 'rgba(0, 0, 0, 0.05)',
              }
            },
            x: {
              grid: {
                display: false,
              }
            }
          },
          plugins: {
            legend: {
              display: false,
            }
          }
        }} />
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 col-span-2">
        <h3 className="text-lg font-semibold mb-4 text-slate-800">Completed Work Overview</h3>
        <Bar data={completedWorkData} options={{
          scales: {
            x: { 
              stacked: true,
              grid: {
                display: false,
              }
            },
            y: { 
              stacked: true,
              grid: {
                color: 'rgba(0, 0, 0, 0.05)',
              }
            }
          },
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                usePointStyle: true,
                padding: 20,
              }
            }
          }
        }} />
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-semibold mb-4 text-slate-800">Notifications Overview</h3>
        <Pie data={notificationsData} options={{
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                usePointStyle: true,
                padding: 20,
              }
            }
          }
        }} />
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-semibold mb-4 text-slate-800">Quick Stats</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
            <p className="text-sm font-medium text-slate-600">Total Tasks</p>
            <p className="text-2xl font-bold text-slate-800">39</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-100">
            <p className="text-sm font-medium text-green-600">Completed</p>
            <p className="text-2xl font-bold text-green-700">24</p>
          </div>
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
            <p className="text-sm font-medium text-blue-600">In Progress</p>
            <p className="text-2xl font-bold text-blue-700">10</p>
          </div>
          <div className="p-4 bg-red-50 rounded-lg border border-red-100">
            <p className="text-sm font-medium text-red-600">Overdue</p>
            <p className="text-2xl font-bold text-red-700">5</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;