import React from 'react';

interface SidebarProps {
  items: {
    icon: React.ReactNode;
    label: string;
    color: string;
    badge?: string;
  }[];
}

const Sidebar: React.FC<SidebarProps> = ({ items }) => {
  return (
    <div className="w-64 bg-white shadow-lg h-screen border-r border-slate-200">
      <div className="p-6">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          WorkPlan
        </h2>
        <p className="text-sm text-slate-500 mt-1">Project Management</p>
      </div>
      <nav className="mt-2">
        {items.map((item, index) => (
          <a
            key={index}
            href="#"
            className={`flex items-center px-6 py-3.5 text-slate-600 hover:bg-slate-50 transition-colors relative group ${
              index === 0 ? 'bg-slate-50' : ''
            }`}
          >
            <span className={`${item.color}`}>{item.icon}</span>
            <span className={`ml-3 font-medium ${index === 0 ? 'text-blue-600' : ''}`}>
              {item.label}
            </span>
            {item.badge && (
              <span className="absolute right-6 bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full text-xs font-medium">
                {item.badge}
              </span>
            )}
            <div className={`absolute left-0 w-1 h-full bg-blue-600 scale-y-0 group-hover:scale-y-100 transition-transform ${
              index === 0 ? 'scale-y-100' : ''
            }`} />
          </a>
        ))}
      </nav>
      <div className="absolute bottom-0 w-64 p-6 border-t border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="flex-shrink-0">
            <img
              src="https://api.dicebear.com/7.x/adventurer/svg?seed=EeshaK&backgroundColor=b6e3f4"
              alt="Profile"
              className="w-10 h-10 rounded-full"
            />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-700">Eesha Kamal</p>
            <p className="text-xs text-slate-500">Project Manager</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;