import React from 'react';
import {
  BarChart,
  PieChart,
  LineChart,
  LayoutDashboard,
  Bell,
  MessageSquare,
  Calendar,
  Users,
  Settings,
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';

const sidebarItems = [
  { icon: <LayoutDashboard size={24} />, label: 'Dashboard', color: 'text-blue-600' },
  { icon: <MessageSquare size={24} />, label: 'Chat', color: 'text-green-600', badge: '3' },
  { icon: <Calendar size={24} />, label: 'Calendar', color: 'text-purple-600' },
  { icon: <Users size={24} />, label: 'Team', color: 'text-orange-600' },
  { icon: <Settings size={24} />, label: 'Settings', color: 'text-gray-600' }
];

function App() {
  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar items={sidebarItems} />
      <div className="flex-1 overflow-hidden">
        <nav className="bg-white shadow-sm px-6 py-3 flex justify-between items-center border-b border-slate-200">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            WorkPlan Dashboard
          </h1>
          <div className="flex items-center space-x-6">
            <button className="p-2 hover:bg-slate-100 rounded-full relative">
              <Bell size={20} className="text-slate-600" />
              <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                4
              </span>
            </button>
            <div className="flex items-center space-x-3">
              <div className="text-right mr-2">
                <p className="text-sm font-medium text-slate-700">Eesha Kamal</p>
                <p className="text-xs text-slate-500">Project Manager</p>
              </div>
              <img
                src="https://api.dicebear.com/7.x/adventurer/svg?seed=EeshaK&backgroundColor=b6e3f4"
                alt="Profile"
                className="w-10 h-10 rounded-full ring-2 ring-blue-100"
              />
            </div>
          </div>
        </nav>
        <main className="p-6 overflow-auto h-[calc(100vh-64px)]">
          <Dashboard />
        </main>
      </div>
    </div>
  );
}

export default App;